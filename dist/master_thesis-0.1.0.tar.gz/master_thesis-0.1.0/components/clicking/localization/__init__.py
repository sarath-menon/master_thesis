from clicking.localization import core

__all__ = ["core"]
