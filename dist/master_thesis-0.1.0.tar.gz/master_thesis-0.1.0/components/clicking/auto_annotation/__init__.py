from clicking.auto_annotation import core

__all__ = ["core"]
