# components/mousetrap/fetch_data/core.py
import random
import time


def fetch_data() -> list:
    """We will fetch a random number of geos"""
    data = [1, 2, 3, 4, 5]
    return data