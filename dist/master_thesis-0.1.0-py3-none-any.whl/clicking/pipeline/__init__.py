from clicking.pipeline.core import Clicker

__all__ = ["Clicker"]
