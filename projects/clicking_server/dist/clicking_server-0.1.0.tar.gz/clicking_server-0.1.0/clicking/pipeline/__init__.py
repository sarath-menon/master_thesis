from clicking.pipeline import core

__all__ = ["core"]
