from clicking.output_corrector import core

__all__ = ["core"]
